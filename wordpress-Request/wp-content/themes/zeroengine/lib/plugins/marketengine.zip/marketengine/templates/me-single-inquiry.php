<?php 
get_header();
echo "<pre>";
print_r(get_query_var('p'));
echo "</pre>";
get_footer();
?>