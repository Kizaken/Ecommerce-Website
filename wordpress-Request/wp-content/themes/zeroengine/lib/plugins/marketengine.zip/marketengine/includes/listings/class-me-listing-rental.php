<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) exit;

class ME_Listing_Rental extends ME_Listing {
	public $price; // per unit
	public $duration; // 
	
}