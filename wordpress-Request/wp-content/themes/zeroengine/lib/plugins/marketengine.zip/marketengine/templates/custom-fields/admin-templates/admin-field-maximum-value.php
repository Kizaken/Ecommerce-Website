<div class="me-group-field">
	<label class="me-title"><?php _e('Maximum value', 'enginethemes'); ?> <small><?php _e('(optional)','enginethemes'); ?></small></label>
	<span class="me-field-control">
		<input class="me-input-field" id="field_maximum_value" type="number" name="field_maximum_value" value="<?php echo $max ?>">
	</span>
</div>