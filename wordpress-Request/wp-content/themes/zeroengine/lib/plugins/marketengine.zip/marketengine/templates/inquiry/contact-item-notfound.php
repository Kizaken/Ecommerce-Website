<?php 
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}
?>
<li>
<?php _e("No item found", "enginethemes"); ?>
</li>