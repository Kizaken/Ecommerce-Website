<?php
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

_e("There are no lisitngs matched with your query.", "enginethemes");