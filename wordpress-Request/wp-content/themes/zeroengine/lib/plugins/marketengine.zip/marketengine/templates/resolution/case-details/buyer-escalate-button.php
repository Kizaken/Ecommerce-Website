<div class="me-col-md-6">
    <div class="me-disputed-escalate">
        <a href="<?php echo add_query_arg('action', 'escalate'); ?>">
            <?php _e("Escalate", "enginethemes"); ?>
        </a>
        <p>
            <?php _e("In case you don't agree with the seller or cannot negotiate with him, press Escalate to let admin arbitrate.", "enginethemes"); ?>
        </p>
    </div>
</div>