<div class="me-load-message">
	<div id="load-older-message" class="load-message-button">
		<div class="me-spinner me-spinner-gray">
			<div class="me-spinner-item1"></div>
			<div class="me-spinner-item2"></div>
			<div class="me-spinner-item3"></div>
			<div class="me-spinner-item4"></div>
		</div>
	</div>
</div>